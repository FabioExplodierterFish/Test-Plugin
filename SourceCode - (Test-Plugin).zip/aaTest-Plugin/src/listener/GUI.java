package listener;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;



public class GUI implements Listener{

	private final String GUI_NAME ="�c�lAuswahl";
	void openGui(Player player) {
		
		ItemStack Sanit�ter = new ItemStack(Material.GOLDEN_APPLE);
		ItemMeta metada = Sanit�ter.getItemMeta();
		metada.setDisplayName("�bSanit�ter");
		Sanit�ter.setItemMeta(metada);
		
		ItemStack K�mpfer = new ItemStack(Material.STONE_SWORD);
		ItemMeta metada1 = K�mpfer.getItemMeta();
		metada1.setDisplayName("�6K�mpfer");
		K�mpfer.setItemMeta(metada1);
		
		Inventory inv = Bukkit.createInventory(null, 9*1, GUI_NAME);
		inv.setItem(2, Sanit�ter);
		inv.setItem(6, K�mpfer);
		player.openInventory(inv);
	}

	@EventHandler
	void join(PlayerJoinEvent e) {
		ItemStack barrier = new ItemStack(Material.BARRIER);
		ItemMeta metada11 = barrier.getItemMeta();
		metada11.setDisplayName("�2Auswahl");
		barrier.setItemMeta(metada11);
		
		Player p = e.getPlayer();
		
		p.getInventory().setItem(4, barrier);
		
		e.setJoinMessage("�a+ �c"+p.getName());
	}
	@EventHandler
	void quit(PlayerQuitEvent e) {

		Player p = e.getPlayer();
		e.setQuitMessage("�a- �c"+p.getName());
	}

	@EventHandler
	void handleNavigator(PlayerInteractEvent e) {

		  if(e.getAction().equals(Action.RIGHT_CLICK_AIR) | e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
	          
	            if(e.getMaterial().equals(Material.BARRIER)) {
	              
		   openGui(e.getPlayer());
	   e.setCancelled(true);
	            }
	            
		  }
	}

	
	@SuppressWarnings("incomplete-switch")
	@EventHandler
	void handleGUIclick(InventoryClickEvent e) {
		if(!(e.getWhoClicked() instanceof Player)) return;
		Player player = (Player)e.getWhoClicked();
		if(e.getClickedInventory().getTitle().equals(GUI_NAME)) {
			e.setCancelled(true);
			switch(e.getCurrentItem().getType()) {
			
			case GOLDEN_APPLE:
				
				player.sendMessage("�aDu hast �bSanit�ter �aausgew�hlt!");
				player.closeInventory();
				
				break;
				
			case STONE_SWORD:
				
				player.sendMessage("�aDu hast �6K�mpfer �aausgew�hlt!");
				player.closeInventory();
				
				break;
				
			
			}

		
		}
	}
	

}
