package de.main;

import org.bukkit.plugin.java.JavaPlugin;

import listener.GUI;

public class Main extends JavaPlugin{

	@Override
	public void onEnable() {
		System.out.println("Plugin erfolgreich geladen!");
		getServer().getPluginManager().registerEvents(new GUI(), this);
	}
	@Override
	public void onDisable() {
		// TODO Auto-generated method stub
		super.onDisable();
	}
}
